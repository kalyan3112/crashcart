import { useState } from 'react';
import { Activity, Layers, Network } from 'lucide-react';
import SensorCard from './components/SensorCard';
import CollaborationHub from './components/CollaborationHub';
import EnhancedMLPanel from './components/EnhancedMLPanel';
import SystemArchitecture from './components/SystemArchitecture';
import EnhancedFleetDashboard from './components/EnhancedFleetDashboard';
import CodeBlueSimulation from './components/CodeBlueSimulation';
import IncidentSummaryModal from './components/IncidentSummaryModal';
import WhatIfScenarioModal from './components/WhatIfScenarioModal';
import IntegrationStrip from './components/IntegrationStrip';
import {
  mockCart,
  mockSensors,
  mockInferences,
  mockTelepresence,
  mockFleetCarts,
  mockFleetAnalytics,
} from './utils/mockData';

type ViewMode = 'cart' | 'architecture' | 'fleet';

function App() {
  const [viewMode, setViewMode] = useState<ViewMode>('cart');
  const [telepresenceActive, setTtelepresenceActive] = useState(false);
  const [codeBlueActive, setCodeBlueActive] = useState(false);
  const [elapsedTime, setElapsedTime] = useState(0);
  const [completedSteps, setCompletedSteps] = useState(0);
  const [showIncidentSummary, setShowIncidentSummary] = useState(false);
  const [showWhatIfScenario, setShowWhatIfScenario] = useState(false);

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 via-blue-50 to-gray-100">
      <header className="bg-white shadow-md border-b-4 border-blue-500">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="bg-gradient-to-br from-blue-500 to-cyan-600 p-3 rounded-lg shadow-lg">
                <Activity className="w-8 h-8 text-white" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-gray-900">
                  Next-Generation Crash Cart System
                </h1>
                <p className="text-sm text-gray-600">
                  Unified IoT Medical Endpoint • {mockCart.serial_number}
                </p>
              </div>
            </div>

            <div className="flex items-center space-x-2">
              <button
                onClick={() => setViewMode('cart')}
                className={`flex items-center space-x-2 px-4 py-2 rounded-lg font-semibold transition-all ${
                  viewMode === 'cart'
                    ? 'bg-blue-500 text-white shadow-lg'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                <Activity className="w-4 h-4" />
                <span>Cart View</span>
              </button>
              <button
                onClick={() => setViewMode('architecture')}
                className={`flex items-center space-x-2 px-4 py-2 rounded-lg font-semibold transition-all ${
                  viewMode === 'architecture'
                    ? 'bg-blue-500 text-white shadow-lg'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                <Layers className="w-4 h-4" />
                <span>Architecture</span>
              </button>
              <button
                onClick={() => setViewMode('fleet')}
                className={`flex items-center space-x-2 px-4 py-2 rounded-lg font-semibold transition-all ${
                  viewMode === 'fleet'
                    ? 'bg-blue-500 text-white shadow-lg'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                <Network className="w-4 h-4" />
                <span>Fleet</span>
              </button>
            </div>
          </div>

          <div className="mt-4 flex items-center space-x-6 text-sm">
            <div className="flex items-center space-x-2">
              <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
              <span className="text-gray-700">
                <span className="font-semibold">Status:</span> {mockCart.status.toUpperCase()}
              </span>
            </div>
            <div className="text-gray-700">
              <span className="font-semibold">Location:</span> {mockCart.location}
            </div>
            <div className="text-gray-700">
              <span className="font-semibold">Firmware:</span> v{mockCart.firmware_version}
            </div>
            <div className="text-gray-700">
              <span className="font-semibold">Last Heartbeat:</span>{' '}
              {new Date(mockCart.last_heartbeat).toLocaleTimeString()}
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-6 py-8">
        {viewMode === 'cart' && (
          <div className="space-y-6">
            <CodeBlueSimulation
              isActive={codeBlueActive}
              onStart={() => {
                setCodeBlueActive(true);
                setTtelepresenceActive(true);
                setElapsedTime(0);
              }}
              onEnd={() => {
                setCodeBlueActive(false);
                setElapsedTime(300);
                setCompletedSteps(7);
                setShowIncidentSummary(true);
              }}
              onGenerateSummary={() => {
                setShowIncidentSummary(true);
              }}
            />

            <section>
              <div className="flex items-center space-x-2 mb-4">
                <Activity className="w-5 h-5 text-blue-600" />
                <h2 className="text-lg font-bold text-gray-800">
                  Multimodal Sensor Array
                </h2>
                <span className="text-sm text-gray-500">
                  (10 synchronized medical devices)
                </span>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
                {mockSensors.map((sensor) => (
                  <SensorCard key={sensor.id} sensor={sensor} isActive={true} />
                ))}
              </div>
            </section>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <CollaborationHub
                sessionActive={telepresenceActive}
                remoteClinician={mockTelepresence.remote_clinician_id}
                onEnd={() => setTtelepresenceActive(false)}
              />
              <EnhancedMLPanel
                inferences={mockInferences}
                onShowWhatIf={() => setShowWhatIfScenario(true)}
              />
            </div>
          </div>
        )}

        {viewMode === 'architecture' && (
          <div className="space-y-6">
            <SystemArchitecture />
            <IntegrationStrip />
          </div>
        )}

        {viewMode === 'fleet' && (
          <EnhancedFleetDashboard carts={mockFleetCarts} analytics={mockFleetAnalytics} />
        )}

        <IncidentSummaryModal
          isOpen={showIncidentSummary}
          onClose={() => setShowIncidentSummary(false)}
          elapsedTime={elapsedTime}
          checklistItems={completedSteps}
          cartSerial={mockCart.serial_number}
          location={mockCart.location}
        />

        <WhatIfScenarioModal
          isOpen={showWhatIfScenario}
          onClose={() => setShowWhatIfScenario(false)}
        />
      </main>

      <footer className="bg-white border-t mt-12">
        <div className="max-w-7xl mx-auto px-6 py-6">
          <div className="grid grid-cols-3 gap-8 text-sm">
            <div>
              <h3 className="font-bold text-gray-800 mb-2">Capabilities</h3>
              <ul className="space-y-1 text-gray-600">
                <li>• Real-time Telepresence</li>
                <li>• Edge ML Processing</li>
                <li>• Synchronized Data Acquisition</li>
                <li>• Fleet-wide Analytics</li>
              </ul>
            </div>
            <div>
              <h3 className="font-bold text-gray-800 mb-2">Data Flow</h3>
              <ul className="space-y-1 text-gray-600">
                <li>• High-frequency sensor streams</li>
                <li>• Sub-50ms edge inference</li>
                <li>• Secure cloud synchronization</li>
                <li>• Multi-cart coordination</li>
              </ul>
            </div>
            <div>
              <h3 className="font-bold text-gray-800 mb-2">Intelligence</h3>
              <ul className="space-y-1 text-gray-600">
                <li>• Triage classification</li>
                <li>• Anomaly detection</li>
                <li>• Image assessment</li>
                <li>• Swarm learning</li>
              </ul>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;
