export interface CrashCart {
  id: string;
  serial_number: string;
  location: string;
  status: 'active' | 'maintenance' | 'offline';
  firmware_version: string;
  last_heartbeat: string;
  metadata: Record<string, unknown>;
  created_at: string;
}

export interface SensorData {
  id: string;
  cart_id: string;
  sensor_type: 'ultrasound' | 'xray' | 'pulse_ox' | 'ecg' | 'bp' | 'temp' | 'resp' | 'spo2' | 'etco2' | 'glucose';
  reading_data: Record<string, unknown>;
  timestamp: string;
  quality_score: number;
  synchronized_session_id?: string;
}

export interface MLInference {
  id: string;
  cart_id: string;
  model_name: string;
  model_version: string;
  inference_type: 'triage' | 'anomaly' | 'image_assessment' | 'risk_score';
  input_sensor_ids: string[];
  output_data: Record<string, unknown>;
  execution_location: 'edge' | 'cloud';
  latency_ms: number;
  timestamp: string;
}

export interface TelepresenceSession {
  id: string;
  cart_id: string;
  remote_clinician_id: string;
  session_start: string;
  session_end?: string;
  video_quality_metrics: {
    bandwidth?: number;
    latency?: number;
    packet_loss?: number;
  };
  interventions_logged: Array<Record<string, unknown>>;
  status: 'active' | 'completed' | 'interrupted';
}

export interface OperationalLog {
  id: string;
  cart_id: string;
  log_level: 'info' | 'warning' | 'error' | 'critical';
  event_type: string;
  message: string;
  metadata: Record<string, unknown>;
  timestamp: string;
}

export interface FleetAnalytics {
  id: string;
  analysis_timestamp: string;
  cart_ids: string[];
  analysis_type: 'pattern_discovery' | 'model_performance' | 'operational_efficiency';
  findings: Record<string, unknown>;
  recommendations: Array<Record<string, unknown>>;
  confidence_score: number;
}
