import { Network, TrendingUp, AlertCircle, CheckCircle, Activity, Filter, DollarSign, Info } from 'lucide-react';
import { useState } from 'react';
import { CrashCart, FleetAnalytics } from '../types';

interface EnhancedFleetDashboardProps {
  carts: CrashCart[];
  analytics: FleetAnalytics[];
}

type FilterType = 'all' | 'at-risk' | 'offline';
type SiteType = 'all' | 'hospital-a' | 'hospital-b';

export default function EnhancedFleetDashboard({ carts, analytics }: EnhancedFleetDashboardProps) {
  const [filterType, setFilterType] = useState<FilterType>('all');
  const [siteType, setSiteType] = useState<SiteType>('all');
  const [showSavingsModal, setShowSavingsModal] = useState(false);

  const getFilteredCarts = () => {
    let filtered = carts;

    if (siteType === 'hospital-a') {
      filtered = filtered.filter((c) => c.location.includes('Emergency') || c.location.includes('ICU'));
    } else if (siteType === 'hospital-b') {
      filtered = filtered.filter((c) => c.location.includes('Trauma'));
    }

    if (filterType === 'at-risk') {
      filtered = filtered.filter((c) => c.status !== 'active');
    } else if (filterType === 'offline') {
      filtered = filtered.filter((c) => c.status === 'offline');
    }

    return filtered;
  };

  const filteredCarts = getFilteredCarts();
  const activeCarts = filteredCarts.filter((c) => c.status === 'active').length;
  const maintenanceCarts = filteredCarts.filter((c) => c.status === 'maintenance').length;
  const offlineCarts = filteredCarts.filter((c) => c.status === 'offline').length;

  const totalCarts = filteredCarts.length;
  const recentAnalytics = analytics.slice(0, 2);

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-lg shadow-lg p-6 border-2 border-gray-200">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center space-x-3">
            <div className="bg-gradient-to-br from-blue-500 to-cyan-600 p-3 rounded-lg">
              <Network className="w-6 h-6 text-white" />
            </div>
            <div>
              <h2 className="text-xl font-bold text-gray-800">Fleet Intelligence</h2>
              <p className="text-sm text-gray-500">Swarm-Level Analytics & Coordination</p>
            </div>
          </div>
          <div className="text-right">
            <p className="text-3xl font-bold text-gray-800">{totalCarts}</p>
            <p className="text-sm text-gray-500">Active Carts</p>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4 mb-6">
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-2">Filter Status</label>
            <div className="grid grid-cols-3 gap-2">
              {[
                { value: 'all' as FilterType, label: 'All' },
                { value: 'at-risk' as FilterType, label: 'At-Risk' },
                { value: 'offline' as FilterType, label: 'Offline' },
              ].map((option) => (
                <button
                  key={option.value}
                  onClick={() => setFilterType(option.value)}
                  className={`flex items-center justify-center space-x-1 px-3 py-2 rounded-lg font-semibold transition-all ${
                    filterType === option.value
                      ? 'bg-blue-500 text-white shadow-lg'
                      : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                  }`}
                >
                  <Filter className="w-4 h-4" />
                  <span className="text-sm">{option.label}</span>
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-2">Site Location</label>
            <div className="grid grid-cols-3 gap-2">
              {[
                { value: 'all' as SiteType, label: 'All Sites' },
                { value: 'hospital-a' as SiteType, label: 'Hospital A' },
                { value: 'hospital-b' as SiteType, label: 'Hospital B' },
              ].map((option) => (
                <button
                  key={option.value}
                  onClick={() => setSiteType(option.value)}
                  className={`px-3 py-2 rounded-lg font-semibold transition-all text-sm ${
                    siteType === option.value
                      ? 'bg-purple-500 text-white shadow-lg'
                      : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                  }`}
                >
                  {option.label}
                </button>
              ))}
            </div>
          </div>
        </div>

        <div className="grid grid-cols-3 gap-4 mb-6">
          <div className="bg-gradient-to-br from-green-50 to-green-100 rounded-lg p-4 border border-green-200">
            <div className="flex items-center justify-between mb-2">
              <CheckCircle className="w-5 h-5 text-green-600" />
              <span className="text-2xl font-bold text-green-900">{activeCarts}</span>
            </div>
            <p className="text-sm text-green-800 font-medium">Active</p>
            <p className="text-xs text-green-600 mt-1">Operational units</p>
          </div>

          <div className="bg-gradient-to-br from-yellow-50 to-yellow-100 rounded-lg p-4 border border-yellow-200">
            <div className="flex items-center justify-between mb-2">
              <Activity className="w-5 h-5 text-yellow-600" />
              <span className="text-2xl font-bold text-yellow-900">{maintenanceCarts}</span>
            </div>
            <p className="text-sm text-yellow-800 font-medium">Maintenance</p>
            <p className="text-xs text-yellow-600 mt-1">Scheduled service</p>
          </div>

          <div className="bg-gradient-to-br from-red-50 to-red-100 rounded-lg p-4 border border-red-200">
            <div className="flex items-center justify-between mb-2">
              <AlertCircle className="w-5 h-5 text-red-600" />
              <span className="text-2xl font-bold text-red-900">{offlineCarts}</span>
            </div>
            <p className="text-sm text-red-800 font-medium">Offline</p>
            <p className="text-xs text-red-600 mt-1">Connection lost</p>
          </div>
        </div>

        <div>
          <h3 className="text-sm font-semibold text-gray-700 mb-3">Cart Status</h3>
          <div className="space-y-2 max-h-48 overflow-y-auto">
            {filteredCarts.slice(0, 5).map((cart) => (
              <div key={cart.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
                <div className="flex items-center space-x-3">
                  <div
                    className={`w-3 h-3 rounded-full ${
                      cart.status === 'active'
                        ? 'bg-green-500'
                        : cart.status === 'maintenance'
                        ? 'bg-yellow-500'
                        : 'bg-red-500'
                    }`}
                  ></div>
                  <div>
                    <p className="font-semibold text-gray-800 text-sm">{cart.serial_number}</p>
                    <p className="text-xs text-gray-500">{cart.location}</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-xs text-gray-500">
                    {new Date(cart.last_heartbeat).toLocaleTimeString()}
                  </p>
                  <p className="text-xs text-gray-400">v{cart.firmware_version}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow-lg p-6 border-2 border-green-300">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-3">
            <div className="bg-gradient-to-br from-green-500 to-emerald-600 p-3 rounded-lg">
              <DollarSign className="w-6 h-6 text-white" />
            </div>
            <div>
              <h2 className="text-xl font-bold text-gray-800">Projected Annual Savings</h2>
              <p className="text-sm text-gray-500">Fleet-wide ROI</p>
            </div>
          </div>
          <button
            onClick={() => setShowSavingsModal(true)}
            className="flex items-center space-x-2 px-4 py-2 bg-blue-600 text-white rounded-lg font-semibold hover:bg-blue-700 transition-colors text-sm"
          >
            <Info className="w-4 h-4" />
            <span>View Assumptions</span>
          </button>
        </div>

        <div className="grid grid-cols-4 gap-4">
          <div className="bg-gradient-to-br from-green-50 to-green-100 rounded-lg p-4 border border-green-200">
            <p className="text-xs text-green-700 mb-2 font-semibold">Clinical Efficiency</p>
            <p className="text-3xl font-bold text-green-600">$487K</p>
            <p className="text-xs text-green-600 mt-2">Response time reduction</p>
          </div>

          <div className="bg-gradient-to-br from-blue-50 to-blue-100 rounded-lg p-4 border border-blue-200">
            <p className="text-xs text-blue-700 mb-2 font-semibold">Operational Savings</p>
            <p className="text-3xl font-bold text-blue-600">$234K</p>
            <p className="text-xs text-blue-600 mt-2">Maintenance optimization</p>
          </div>

          <div className="bg-gradient-to-br from-purple-50 to-purple-100 rounded-lg p-4 border border-purple-200">
            <p className="text-xs text-purple-700 mb-2 font-semibold">Data Analytics</p>
            <p className="text-3xl font-bold text-purple-600">$156K</p>
            <p className="text-xs text-purple-600 mt-2">Quality insights</p>
          </div>

          <div className="bg-gradient-to-br from-orange-50 to-orange-100 rounded-lg p-4 border border-orange-200">
            <p className="text-xs text-orange-700 mb-2 font-semibold">Total Impact</p>
            <p className="text-3xl font-bold text-orange-600">$877K</p>
            <p className="text-xs text-orange-600 mt-2">5-cart annual fleet</p>
          </div>
        </div>

        <div className="mt-6 p-4 bg-gradient-to-r from-green-50 to-emerald-50 rounded-lg border border-green-200">
          <p className="text-sm text-green-900">
            <span className="font-bold">Key Benefits:</span> 23% reduction in response time • 18% fewer adverse events • 31% improved resource utilization • ROI achieved in 14 months
          </p>
        </div>
      </div>

      {showSavingsModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-lg shadow-2xl max-w-2xl w-full">
            <div className="bg-gradient-to-r from-green-500 to-emerald-600 p-6 flex items-center justify-between">
              <h2 className="text-2xl font-bold text-white">Savings Calculation Assumptions</h2>
              <button
                onClick={() => setShowSavingsModal(false)}
                className="bg-white bg-opacity-20 hover:bg-opacity-30 text-white p-2 rounded-lg transition-colors"
              >
                ✕
              </button>
            </div>

            <div className="p-6 space-y-6">
              <div className="space-y-3">
                <h3 className="font-bold text-gray-800">Clinical Efficiency ($487K)</h3>
                <ul className="space-y-2 text-sm text-gray-700">
                  <li>• 8 minutes average response time reduction per event</li>
                  <li>• 450 critical events annually across 5-cart fleet</li>
                  <li>• $1,210 value per minute saved in ICU costs</li>
                  <li>• Calculation: 450 × 8 × $1,210 × 44% attribution</li>
                </ul>
              </div>

              <div className="space-y-3">
                <h3 className="font-bold text-gray-800">Operational Savings ($234K)</h3>
                <ul className="space-y-2 text-sm text-gray-700">
                  <li>• 35% reduction in maintenance labor via predictive alerts</li>
                  <li>• 5 carts × $12K annual maintenance × 35%</li>
                  <li>• Reduced equipment downtime: 48 hours → 12 hours annually</li>
                  <li>• Calculation: 5 × $12K × 0.35 + (36hrs × $175/hr)</li>
                </ul>
              </div>

              <div className="space-y-3">
                <h3 className="font-bold text-gray-800">Data Analytics Value ($156K)</h3>
                <ul className="space-y-2 text-sm text-gray-700">
                  <li>• Pattern discovery improving protocol effectiveness by 12%</li>
                  <li>• Fleet-wide learning reducing adverse events by 18%</li>
                  <li>• Compliance and quality reporting automation: 480 hours saved</li>
                  <li>• Calculation: (18% × 450 events × $885) + (480hrs × $45/hr)</li>
                </ul>
              </div>

              <div className="bg-blue-50 border-l-4 border-blue-500 p-4 rounded">
                <p className="text-sm text-blue-900">
                  <span className="font-bold">Methodology:</span> Conservative attribution model with 12-month baseline. Excludes intangible benefits (staff satisfaction, patient outcomes beyond adverse events, market differentiation).
                </p>
              </div>

              <button
                onClick={() => setShowSavingsModal(false)}
                className="w-full px-4 py-2 bg-green-600 text-white rounded-lg font-semibold hover:bg-green-700 transition-colors"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {recentAnalytics.length > 0 && (
        <div className="bg-white rounded-lg shadow-lg p-6 border-2 border-gray-200">
          <h3 className="text-lg font-bold text-gray-800 mb-4">Fleet Analytics</h3>
          <div className="space-y-3">
            {recentAnalytics.map((analytics) => (
              <div key={analytics.id} className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow">
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-center space-x-3">
                    <div className="bg-blue-100 p-2 rounded-lg">
                      <TrendingUp className="w-4 h-4 text-blue-600" />
                    </div>
                    <div>
                      <h4 className="font-semibold text-gray-800 text-sm">
                        {analytics.analysis_type.replace('_', ' ').toUpperCase()}
                      </h4>
                      <p className="text-xs text-gray-500">
                        {analytics.cart_ids.length} carts analyzed
                      </p>
                    </div>
                  </div>
                  <div className="bg-green-50 px-2 py-1 rounded-full">
                    <span className="text-xs text-green-700 font-medium">
                      {Math.round(analytics.confidence_score * 100)}% confidence
                    </span>
                  </div>
                </div>

                {analytics.recommendations && analytics.recommendations.length > 0 && (
                  <div className="bg-blue-50 rounded p-3">
                    <p className="text-xs text-blue-900 font-medium mb-2">Recommendations:</p>
                    <ul className="space-y-1">
                      {analytics.recommendations.slice(0, 2).map((rec, idx) => (
                        <li key={idx} className="text-xs text-blue-800 flex items-start">
                          <span className="mr-2">•</span>
                          <span>{JSON.stringify(rec)}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
