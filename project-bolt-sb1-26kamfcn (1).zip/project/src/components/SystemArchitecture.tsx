import { Database, Cloud, Cpu, Radio, Network, Shield } from 'lucide-react';

export default function SystemArchitecture() {
  return (
    <div className="bg-white rounded-lg shadow-lg p-6 border-2 border-gray-200">
      <div className="mb-6">
        <h2 className="text-xl font-bold text-gray-800 mb-2">System Architecture</h2>
        <p className="text-sm text-gray-500">Unified IoT Endpoint with Multi-Tier Intelligence</p>
      </div>

      <div className="space-y-6">
        <div className="relative">
          <div className="grid grid-cols-3 gap-4">
            <div className="col-span-3 bg-gradient-to-br from-blue-50 to-blue-100 rounded-lg p-6 border-2 border-blue-200">
              <div className="flex items-center space-x-3 mb-4">
                <div className="bg-blue-500 p-2 rounded-lg">
                  <Radio className="w-5 h-5 text-white" />
                </div>
                <div>
                  <h3 className="font-bold text-blue-900">Crash Cart Edge Device</h3>
                  <p className="text-xs text-blue-700">Physical IoT Endpoint</p>
                </div>
              </div>

              <div className="grid grid-cols-5 gap-2 mb-4">
                {['Ultrasound', 'X-Ray', 'ECG', 'Pulse Ox', 'BP', 'Temp', 'SpO2', 'Resp', 'EtCO2', 'Glucose'].slice(0, 5).map((sensor) => (
                  <div key={sensor} className="bg-white rounded p-2 text-center border border-blue-300">
                    <div className="w-full h-8 bg-blue-200 rounded mb-1"></div>
                    <p className="text-xs text-blue-900 font-medium">{sensor}</p>
                  </div>
                ))}
              </div>

              <div className="flex items-center justify-center space-x-2 text-blue-700 text-sm">
                <div className="flex-1 h-0.5 bg-blue-300"></div>
                <span className="font-semibold">10 Medical Sensors</span>
                <div className="flex-1 h-0.5 bg-blue-300"></div>
              </div>
            </div>
          </div>

          <div className="flex justify-center my-4">
            <div className="flex flex-col items-center">
              <div className="w-0.5 h-8 bg-gray-300"></div>
              <div className="bg-gray-200 rounded-full p-2">
                <Network className="w-4 h-4 text-gray-600" />
              </div>
              <div className="w-0.5 h-8 bg-gray-300"></div>
            </div>
          </div>

          <div className="grid grid-cols-3 gap-4 mb-4">
            <div className="bg-gradient-to-br from-purple-50 to-purple-100 rounded-lg p-4 border-2 border-purple-200">
              <div className="flex items-center space-x-2 mb-3">
                <div className="bg-purple-500 p-2 rounded-lg">
                  <Cpu className="w-4 h-4 text-white" />
                </div>
                <h3 className="font-bold text-purple-900 text-sm">Edge ML</h3>
              </div>
              <ul className="space-y-1 text-xs text-purple-800">
                <li>• Triage Classification</li>
                <li>• Anomaly Detection</li>
                <li>• Real-time Assessment</li>
              </ul>
            </div>

            <div className="bg-gradient-to-br from-green-50 to-green-100 rounded-lg p-4 border-2 border-green-200">
              <div className="flex items-center space-x-2 mb-3">
                <div className="bg-green-500 p-2 rounded-lg">
                  <Radio className="w-4 h-4 text-white" />
                </div>
                <h3 className="font-bold text-green-900 text-sm">Telepresence</h3>
              </div>
              <ul className="space-y-1 text-xs text-green-800">
                <li>• Bidirectional Video</li>
                <li>• Low-latency Streaming</li>
                <li>• Remote Guidance</li>
              </ul>
            </div>

            <div className="bg-gradient-to-br from-orange-50 to-orange-100 rounded-lg p-4 border-2 border-orange-200">
              <div className="flex items-center space-x-2 mb-3">
                <div className="bg-orange-500 p-2 rounded-lg">
                  <Shield className="w-4 h-4 text-white" />
                </div>
                <h3 className="font-bold text-orange-900 text-sm">Data Sync</h3>
              </div>
              <ul className="space-y-1 text-xs text-orange-800">
                <li>• Secure Transmission</li>
                <li>• Time Synchronization</li>
                <li>• Multimodal Alignment</li>
              </ul>
            </div>
          </div>

          <div className="flex justify-center my-4">
            <div className="flex flex-col items-center">
              <div className="w-0.5 h-8 bg-gray-300"></div>
              <div className="bg-gray-200 rounded-full p-2">
                <Cloud className="w-4 h-4 text-gray-600" />
              </div>
              <div className="w-0.5 h-8 bg-gray-300"></div>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="bg-gradient-to-br from-indigo-50 to-indigo-100 rounded-lg p-4 border-2 border-indigo-200">
              <div className="flex items-center space-x-2 mb-3">
                <div className="bg-indigo-500 p-2 rounded-lg">
                  <Database className="w-4 h-4 text-white" />
                </div>
                <h3 className="font-bold text-indigo-900 text-sm">Central Repository</h3>
              </div>
              <ul className="space-y-1 text-xs text-indigo-800">
                <li>• Sensor Data Store</li>
                <li>• Inference Archive</li>
                <li>• Session Records</li>
                <li>• Operational Logs</li>
              </ul>
            </div>

            <div className="bg-gradient-to-br from-pink-50 to-pink-100 rounded-lg p-4 border-2 border-pink-200">
              <div className="flex items-center space-x-2 mb-3">
                <div className="bg-pink-500 p-2 rounded-lg">
                  <Network className="w-4 h-4 text-white" />
                </div>
                <h3 className="font-bold text-pink-900 text-sm">Fleet Analytics</h3>
              </div>
              <ul className="space-y-1 text-xs text-pink-800">
                <li>• Swarm Intelligence</li>
                <li>• Pattern Discovery</li>
                <li>• Model Optimization</li>
                <li>• Cross-Cart Learning</li>
              </ul>
            </div>
          </div>
        </div>

        <div className="border-t pt-4">
          <h3 className="text-sm font-semibold text-gray-700 mb-3">Data Flow Characteristics</h3>
          <div className="grid grid-cols-3 gap-3 text-xs">
            <div className="bg-gray-50 rounded-lg p-3">
              <p className="text-gray-500 mb-1">Sensor Acquisition</p>
              <p className="font-semibold text-gray-800">100-1000 Hz</p>
              <p className="text-gray-400 mt-1">High-frequency synchronized capture</p>
            </div>
            <div className="bg-gray-50 rounded-lg p-3">
              <p className="text-gray-500 mb-1">Edge Inference</p>
              <p className="font-semibold text-gray-800">&lt;50ms</p>
              <p className="text-gray-400 mt-1">Real-time local processing</p>
            </div>
            <div className="bg-gray-50 rounded-lg p-3">
              <p className="text-gray-500 mb-1">Cloud Sync</p>
              <p className="font-semibold text-gray-800">Continuous</p>
              <p className="text-gray-400 mt-1">Batched secure transmission</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
