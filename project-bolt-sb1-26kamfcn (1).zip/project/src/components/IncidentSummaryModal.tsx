import { X, Download, Share2, AlertCircle, CheckCircle, Clock } from 'lucide-react';

interface IncidentSummaryModalProps {
  isOpen: boolean;
  onClose: () => void;
  elapsedTime: number;
  checklistItems: number;
  cartSerial: string;
  location: string;
}

export default function IncidentSummaryModal({
  isOpen,
  onClose,
  elapsedTime,
  checklistItems,
  cartSerial,
  location,
}: IncidentSummaryModalProps) {
  if (!isOpen) return null;

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-lg shadow-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        <div className="sticky top-0 bg-gradient-to-r from-red-500 to-red-600 p-6 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <AlertCircle className="w-8 h-8 text-white" />
            <h2 className="text-2xl font-bold text-white">Incident Summary Report</h2>
          </div>
          <button
            onClick={onClose}
            className="bg-red-400 hover:bg-red-700 text-white p-2 rounded-lg transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        <div className="p-6 space-y-6">
          <div className="grid grid-cols-3 gap-4">
            <div className="bg-red-50 rounded-lg p-4 border-l-4 border-red-500">
              <div className="flex items-center space-x-2 mb-1">
                <Clock className="w-5 h-5 text-red-600" />
                <p className="text-sm text-red-900 font-semibold">Response Time</p>
              </div>
              <p className="text-2xl font-bold text-red-600">{formatTime(elapsedTime)}</p>
            </div>

            <div className="bg-green-50 rounded-lg p-4 border-l-4 border-green-500">
              <div className="flex items-center space-x-2 mb-1">
                <CheckCircle className="w-5 h-5 text-green-600" />
                <p className="text-sm text-green-900 font-semibold">Steps Completed</p>
              </div>
              <p className="text-2xl font-bold text-green-600">{checklistItems}/7</p>
            </div>

            <div className="bg-blue-50 rounded-lg p-4 border-l-4 border-blue-500">
              <div className="flex items-center space-x-2 mb-1">
                <AlertCircle className="w-5 h-5 text-blue-600" />
                <p className="text-sm text-blue-900 font-semibold">Timestamp</p>
              </div>
              <p className="text-lg font-bold text-blue-600">
                {new Date().toLocaleTimeString()}
              </p>
            </div>
          </div>

          <div className="border-t pt-6">
            <h3 className="text-lg font-bold text-gray-800 mb-4">Device Information</h3>
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-gray-50 rounded-lg p-4">
                <p className="text-sm text-gray-600 mb-1">Cart Serial</p>
                <p className="text-lg font-semibold text-gray-800">{cartSerial}</p>
              </div>
              <div className="bg-gray-50 rounded-lg p-4">
                <p className="text-sm text-gray-600 mb-1">Location</p>
                <p className="text-lg font-semibold text-gray-800">{location}</p>
              </div>
            </div>
          </div>

          <div className="border-t pt-6">
            <h3 className="text-lg font-bold text-gray-800 mb-4">Clinical Actions</h3>
            <div className="space-y-3">
              {[
                { label: 'Activate Code Blue Protocol', time: '0:05' },
                { label: 'Initiate CPR & Defibrillation', time: '0:15' },
                { label: 'Establish IV Access', time: '0:25' },
                { label: 'Administer Medications', time: '0:40' },
                { label: 'Confirm Rhythm Check', time: '0:50' },
                { label: 'Notify Intensive Care Unit', time: 'N/A' },
                { label: 'Prepare Transport', time: 'N/A' },
              ].map((action, idx) => (
                <div key={idx} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                  <div className="flex items-center space-x-3">
                    <CheckCircle className="w-5 h-5 text-green-500" />
                    <span className="text-gray-800 font-medium">{action.label}</span>
                  </div>
                  <span className="text-sm text-gray-600 font-mono">{action.time}</span>
                </div>
              ))}
            </div>
          </div>

          <div className="border-t pt-6">
            <h3 className="text-lg font-bold text-gray-800 mb-4">Sensor Data Capture</h3>
            <p className="text-sm text-gray-600 mb-3">
              Multimodal sensor data synchronized and archived for post-event analysis
            </p>
            <div className="grid grid-cols-2 gap-2 text-sm">
              {['ECG', 'Pulse Ox', 'BP', 'Temperature', 'Ultrasound', 'X-Ray'].map((sensor) => (
                <div key={sensor} className="bg-blue-50 p-2 rounded border border-blue-200 text-blue-800 font-semibold flex items-center">
                  <span className="w-2 h-2 bg-blue-500 rounded-full mr-2"></span>
                  {sensor}
                </div>
              ))}
            </div>
          </div>

          <div className="bg-yellow-50 border-l-4 border-yellow-500 p-4 rounded">
            <p className="text-sm text-yellow-900">
              <span className="font-semibold">Note:</span> This incident has been automatically logged and is available for quality review, training, and compliance reporting.
            </p>
          </div>

          <div className="flex items-center space-x-3 pt-6 border-t">
            <button
              onClick={onClose}
              className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg font-semibold hover:bg-blue-700 transition-colors flex items-center justify-center space-x-2"
            >
              <Share2 className="w-4 h-4" />
              <span>Share Report</span>
            </button>
            <button
              onClick={onClose}
              className="flex-1 px-4 py-2 bg-gray-200 text-gray-800 rounded-lg font-semibold hover:bg-gray-300 transition-colors flex items-center justify-center space-x-2"
            >
              <Download className="w-4 h-4" />
              <span>Download PDF</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
