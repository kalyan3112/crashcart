import { Brain, Cpu, Cloud, Zap, TrendingUp, Settings } from 'lucide-react';
import { useState } from 'react';
import { MLInference } from '../types';

interface EnhancedMLPanelProps {
  inferences: MLInference[];
  onShowWhatIf: () => void;
}

export default function EnhancedMLPanel({ inferences, onShowWhatIf }: EnhancedMLPanelProps) {
  const recentInferences = inferences.slice(0, 5);
  const [expandedModel, setExpandedModel] = useState<string | null>(null);

  const getInferenceIcon = (type: string) => {
    switch (type) {
      case 'triage':
        return TrendingUp;
      case 'anomaly':
        return Zap;
      case 'image_assessment':
        return Brain;
      case 'risk_score':
        return TrendingUp;
      default:
        return Brain;
    }
  };

  const getInferenceColor = (type: string) => {
    switch (type) {
      case 'triage':
        return 'bg-blue-500';
      case 'anomaly':
        return 'bg-red-500';
      case 'image_assessment':
        return 'bg-purple-500';
      case 'risk_score':
        return 'bg-orange-500';
      default:
        return 'bg-gray-500';
    }
  };

  const getAccuracyColor = (accuracy: number) => {
    if (accuracy >= 95) return 'text-green-600';
    if (accuracy >= 90) return 'text-blue-600';
    if (accuracy >= 85) return 'text-yellow-600';
    return 'text-red-600';
  };

  const getLatencyColor = (latency: number) => {
    if (latency <= 50) return 'text-green-600';
    if (latency <= 100) return 'text-blue-600';
    if (latency <= 200) return 'text-yellow-600';
    return 'text-red-600';
  };

  const modelStats = {
    avgLatency: Math.round(inferences.reduce((sum, i) => sum + i.latency_ms, 0) / inferences.length),
    avgAccuracy: 93.5,
    edgeCount: inferences.filter((i) => i.execution_location === 'edge').length,
    cloudCount: inferences.filter((i) => i.execution_location === 'cloud').length,
  };

  return (
    <div className="bg-white rounded-lg shadow-lg p-6 border-2 border-gray-200">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center space-x-3">
          <div className="bg-gradient-to-br from-purple-500 to-blue-600 p-3 rounded-lg">
            <Brain className="w-6 h-6 text-white" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-gray-800">Edge Intelligence</h2>
            <p className="text-sm text-gray-500">On-Device ML Inferences</p>
          </div>
        </div>
        <button
          onClick={onShowWhatIf}
          className="flex items-center space-x-2 px-4 py-2 bg-purple-600 text-white rounded-lg font-semibold hover:bg-purple-700 transition-colors text-sm"
        >
          <Settings className="w-4 h-4" />
          <span>What-If</span>
        </button>
      </div>

      <div className="grid grid-cols-2 gap-3 mb-6">
        <div className="bg-gradient-to-br from-blue-50 to-blue-100 rounded-lg p-4 border border-blue-200">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center space-x-2">
              <Cpu className="w-5 h-5 text-blue-600" />
              <span className="text-sm font-semibold text-blue-900">Avg Latency</span>
            </div>
            <span className={`text-lg font-bold ${getLatencyColor(modelStats.avgLatency)}`}>
              {modelStats.avgLatency}ms
            </span>
          </div>
          <p className="text-xs text-blue-700">Sub-100ms edge processing</p>
        </div>

        <div className="bg-gradient-to-br from-green-50 to-green-100 rounded-lg p-4 border border-green-200">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center space-x-2">
              <TrendingUp className="w-5 h-5 text-green-600" />
              <span className="text-sm font-semibold text-green-900">Avg Accuracy</span>
            </div>
            <span className={`text-lg font-bold ${getAccuracyColor(modelStats.avgAccuracy)}`}>
              {modelStats.avgAccuracy}%
            </span>
          </div>
          <p className="text-xs text-green-700">Fleet-wide average</p>
        </div>

        <div className="bg-gradient-to-br from-orange-50 to-orange-100 rounded-lg p-4 border border-orange-200">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center space-x-2">
              <Cpu className="w-5 h-5 text-orange-600" />
              <span className="text-sm font-semibold text-orange-900">Edge Execution</span>
            </div>
            <span className="text-lg font-bold text-orange-600">{modelStats.edgeCount}</span>
          </div>
          <p className="text-xs text-orange-700">Low-latency local</p>
        </div>

        <div className="bg-gradient-to-br from-purple-50 to-purple-100 rounded-lg p-4 border border-purple-200">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center space-x-2">
              <Cloud className="w-5 h-5 text-purple-600" />
              <span className="text-sm font-semibold text-purple-900">Cloud Execution</span>
            </div>
            <span className="text-lg font-bold text-purple-600">{modelStats.cloudCount}</span>
          </div>
          <p className="text-xs text-purple-700">Advanced models</p>
        </div>
      </div>

      <div className="space-y-3">
        <h3 className="text-sm font-semibold text-gray-700">Model Performance</h3>
        {recentInferences.length > 0 ? (
          recentInferences.map((inference) => {
            const Icon = getInferenceIcon(inference.inference_type);
            const colorClass = getInferenceColor(inference.inference_type);
            const isExpanded = expandedModel === inference.id;

            return (
              <div
                key={inference.id}
                className="border border-gray-200 rounded-lg hover:shadow-md transition-shadow"
              >
                <button
                  onClick={() => setExpandedModel(isExpanded ? null : inference.id)}
                  className="w-full p-4 text-left hover:bg-gray-50 transition-colors"
                >
                  <div className="flex items-start justify-between mb-2">
                    <div className="flex items-center space-x-3 flex-1">
                      <div className={`${colorClass} p-2 rounded-lg flex-shrink-0`}>
                        <Icon className="w-4 h-4 text-white" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <h4 className="font-semibold text-gray-800 text-sm">{inference.model_name}</h4>
                        <p className="text-xs text-gray-500">
                          {inference.inference_type.replace('_', ' ').toUpperCase()} • v{inference.model_version}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      {inference.execution_location === 'edge' ? (
                        <div className="flex items-center space-x-1 bg-blue-50 px-2 py-1 rounded-full">
                          <Cpu className="w-3 h-3 text-blue-600" />
                          <span className="text-xs text-blue-600 font-medium">EDGE</span>
                        </div>
                      ) : (
                        <div className="flex items-center space-x-1 bg-purple-50 px-2 py-1 rounded-full">
                          <Cloud className="w-3 h-3 text-purple-600" />
                          <span className="text-xs text-purple-600 font-medium">CLOUD</span>
                        </div>
                      )}
                    </div>
                  </div>

                  <div className="grid grid-cols-3 gap-2 text-xs">
                    <div className="flex items-center space-x-1">
                      <span className="text-gray-500">Latency:</span>
                      <span className={`font-bold ${getLatencyColor(inference.latency_ms)}`}>
                        {inference.latency_ms}ms
                      </span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <span className="text-gray-500">Time:</span>
                      <span className="font-mono text-gray-700">
                        {new Date(inference.timestamp).toLocaleTimeString()}
                      </span>
                    </div>
                    <div className="text-right text-gray-600">
                      {isExpanded ? '▼' : '▶'} Details
                    </div>
                  </div>
                </button>

                {isExpanded && inference.output_data && Object.keys(inference.output_data).length > 0 && (
                  <div className="border-t bg-gray-50 p-4 space-y-2">
                    <p className="text-xs font-semibold text-gray-700 mb-2">Inference Output</p>
                    {Object.entries(inference.output_data).map(([key, value]) => (
                      <div key={key} className="flex justify-between text-xs bg-white p-2 rounded border border-gray-200">
                        <span className="text-gray-500 font-semibold">{key}:</span>
                        <span className="font-mono text-gray-800">{String(value)}</span>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            );
          })
        ) : (
          <div className="py-8 text-center">
            <Brain className="w-12 h-12 text-gray-300 mx-auto mb-2" />
            <p className="text-gray-500 text-sm">No inferences available</p>
          </div>
        )}
      </div>

      <div className="border-t mt-4 pt-4">
        <div className="grid grid-cols-3 gap-3 text-xs">
          <div className="bg-gray-50 rounded-lg p-3">
            <p className="text-gray-500 mb-1 font-semibold">Model Update</p>
            <p className="font-semibold text-gray-800">Federated Learning</p>
          </div>
          <div className="bg-gray-50 rounded-lg p-3">
            <p className="text-gray-500 mb-1 font-semibold">Last Sync</p>
            <p className="font-semibold text-gray-800">2 hours ago</p>
          </div>
          <div className="bg-gray-50 rounded-lg p-3">
            <p className="text-gray-500 mb-1 font-semibold">Fleet Improvement</p>
            <p className="font-semibold text-green-600">+2.3% accuracy</p>
          </div>
        </div>
      </div>
    </div>
  );
}
