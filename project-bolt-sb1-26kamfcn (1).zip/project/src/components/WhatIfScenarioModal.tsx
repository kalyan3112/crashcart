import { X, Brain, Zap, Cloud, TrendingUp } from 'lucide-react';
import { useState } from 'react';

interface WhatIfScenarioModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function WhatIfScenarioModal({ isOpen, onClose }: WhatIfScenarioModalProps) {
  const [selectedScenario, setSelectedScenario] = useState<'edge' | 'cloud' | 'hybrid'>('hybrid');

  if (!isOpen) return null;

  const scenarios = {
    edge: {
      label: 'Edge Only',
      latency: '28-42ms',
      accuracy: '91.2%',
      powerUsage: '18W',
      connectivity: 'Not required',
      models: ['TriageNet-v3', 'CardiacAnomalyDetector', 'RiskStratification'],
      pros: ['Immediate response', 'Offline capable', 'Lower bandwidth'],
      cons: ['Limited model complexity', 'No real-time updates', 'Local storage constraints'],
    },
    cloud: {
      label: 'Cloud Only',
      latency: '150-280ms',
      accuracy: '96.8%',
      powerUsage: '8W',
      connectivity: 'Required',
      models: ['UltrasoundAnalyzer', 'XRayClassifier', 'AdvancedRiskModel'],
      pros: ['Highest accuracy', 'Advanced models', 'Real-time updates'],
      cons: ['Connectivity dependent', 'Higher latency', 'Privacy considerations'],
    },
    hybrid: {
      label: 'Hybrid (Recommended)',
      latency: '67-89ms',
      accuracy: '94.5%',
      powerUsage: '12W',
      connectivity: 'Optimal',
      models: ['All 5 models + ensemble'],
      pros: ['Best of both worlds', 'Resilient', 'Optimal performance'],
      cons: ['Most complex', 'Highest power usage'],
    },
  };

  const current = scenarios[selectedScenario];

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-lg shadow-2xl max-w-3xl w-full max-h-[90vh] overflow-y-auto">
        <div className="sticky top-0 bg-gradient-to-r from-purple-500 to-blue-600 p-6 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <Brain className="w-8 h-8 text-white" />
            <h2 className="text-2xl font-bold text-white">ML Execution What-If Scenario</h2>
          </div>
          <button
            onClick={onClose}
            className="bg-white bg-opacity-20 hover:bg-opacity-30 text-white p-2 rounded-lg transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        <div className="p-6 space-y-6">
          <div className="grid grid-cols-3 gap-4">
            {Object.entries(scenarios).map(([key, scenario]) => (
              <button
                key={key}
                onClick={() => setSelectedScenario(key as 'edge' | 'cloud' | 'hybrid')}
                className={`p-4 rounded-lg border-2 transition-all text-left ${
                  selectedScenario === key
                    ? 'border-blue-500 bg-blue-50 shadow-lg'
                    : 'border-gray-200 bg-white hover:border-gray-300'
                }`}
              >
                <div className="flex items-center space-x-2 mb-2">
                  {key === 'edge' ? (
                    <Zap className="w-5 h-5 text-orange-500" />
                  ) : key === 'cloud' ? (
                    <Cloud className="w-5 h-5 text-blue-500" />
                  ) : (
                    <Brain className="w-5 h-5 text-purple-500" />
                  )}
                  <span className="font-bold text-gray-800">{scenario.label}</span>
                </div>
                <p className="text-xs text-gray-600">{scenario.latency} latency</p>
              </button>
            ))}
          </div>

          <div className="bg-gradient-to-br from-blue-50 to-purple-50 rounded-lg p-6 border-2 border-blue-200">
            <div className="grid grid-cols-4 gap-4">
              <div>
                <p className="text-xs text-gray-600 mb-1 font-semibold">LATENCY</p>
                <p className="text-2xl font-bold text-blue-600">{current.latency}</p>
                <p className="text-xs text-gray-500 mt-1">Response time</p>
              </div>
              <div>
                <p className="text-xs text-gray-600 mb-1 font-semibold">ACCURACY</p>
                <p className="text-2xl font-bold text-green-600">{current.accuracy}</p>
                <p className="text-xs text-gray-500 mt-1">Inference quality</p>
              </div>
              <div>
                <p className="text-xs text-gray-600 mb-1 font-semibold">POWER</p>
                <p className="text-2xl font-bold text-orange-600">{current.powerUsage}</p>
                <p className="text-xs text-gray-500 mt-1">Consumption rate</p>
              </div>
              <div>
                <p className="text-xs text-gray-600 mb-1 font-semibold">CONNECTIVITY</p>
                <p className={`text-lg font-bold ${
                  current.connectivity === 'Required'
                    ? 'text-red-600'
                    : current.connectivity === 'Optimal'
                    ? 'text-green-600'
                    : 'text-gray-600'
                }`}>
                  {current.connectivity === 'Not required' ? '✓ Optional' : current.connectivity}
                </p>
                <p className="text-xs text-gray-500 mt-1">Network needs</p>
              </div>
            </div>
          </div>

          <div className="border-t pt-6">
            <h3 className="text-lg font-bold text-gray-800 mb-4">Active Models in This Configuration</h3>
            <div className="grid grid-cols-2 gap-3">
              {current.models.map((model) => (
                <div key={model} className="bg-purple-50 rounded-lg p-3 border border-purple-200 flex items-start space-x-2">
                  <Brain className="w-4 h-4 text-purple-600 mt-1 flex-shrink-0" />
                  <span className="text-sm font-semibold text-purple-900">{model}</span>
                </div>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-2 gap-6 border-t pt-6">
            <div>
              <h4 className="font-bold text-green-800 mb-3 flex items-center space-x-2">
                <TrendingUp className="w-5 h-5" />
                <span>Advantages</span>
              </h4>
              <ul className="space-y-2">
                {current.pros.map((pro, idx) => (
                  <li key={idx} className="flex items-start space-x-2 text-sm text-green-800">
                    <span className="text-green-600 font-bold mt-0.5">✓</span>
                    <span>{pro}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div>
              <h4 className="font-bold text-orange-800 mb-3 flex items-center space-x-2">
                <AlertTriangle className="w-5 h-5" />
                <span>Trade-offs</span>
              </h4>
              <ul className="space-y-2">
                {current.cons.map((con, idx) => (
                  <li key={idx} className="flex items-start space-x-2 text-sm text-orange-800">
                    <span className="text-orange-600 font-bold mt-0.5">!</span>
                    <span>{con}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          {selectedScenario === 'hybrid' && (
            <div className="bg-green-50 border-l-4 border-green-500 p-4 rounded">
              <p className="text-sm text-green-900">
                <span className="font-bold">Recommended:</span> The hybrid approach automatically routes inferences to edge or cloud based on model complexity, network availability, and real-time load. This maximizes responsiveness while maintaining accuracy during critical events.
              </p>
            </div>
          )}

          <div className="flex items-center space-x-3 pt-6 border-t">
            <button
              onClick={onClose}
              className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg font-semibold hover:bg-blue-700 transition-colors"
            >
              Apply Configuration
            </button>
            <button
              onClick={onClose}
              className="flex-1 px-4 py-2 bg-gray-200 text-gray-800 rounded-lg font-semibold hover:bg-gray-300 transition-colors"
            >
              Close
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

interface AlertTriangleProps {
  className?: string;
}

function AlertTriangle({ className }: AlertTriangleProps) {
  return (
    <svg
      className={className}
      fill="none"
      stroke="currentColor"
      viewBox="0 0 24 24"
    >
      <path
        strokeLinecap="round"
        strokeLinejoin="round"
        strokeWidth={2}
        d="M12 8v4m0 4v.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
      />
    </svg>
  );
}
