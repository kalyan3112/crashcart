import { Video, Send, AlertTriangle, Camera, Plus, Clock, Users, CheckCircle } from 'lucide-react';
import { useState } from 'react';

interface TimelineEvent {
  id: string;
  timestamp: string;
  action: string;
  actor: string;
  details: string;
}

interface CollaborationHubProps {
  sessionActive: boolean;
  remoteClinician: string;
  onEnd: () => void;
}

export default function CollaborationHub({
  sessionActive,
  remoteClinician,
  onEnd,
}: CollaborationHubProps) {
  const [timeline, setTimeline] = useState<TimelineEvent[]>([
    {
      id: '1',
      timestamp: new Date(Date.now() - 180000).toLocaleTimeString(),
      action: 'Session Started',
      actor: remoteClinician,
      details: 'Video connection established',
    },
  ]);

  const [showActionMenu, setShowActionMenu] = useState(false);

  const addTimelineEvent = (action: string, details: string) => {
    const event: TimelineEvent = {
      id: Date.now().toString(),
      timestamp: new Date().toLocaleTimeString(),
      action,
      actor: remoteClinician,
      details,
    };
    setTimeline((prev) => [event, ...prev]);
    setShowActionMenu(false);
  };

  const handleEscalate = () => {
    addTimelineEvent('Escalate to Specialist', 'Cardiology consultation requested');
  };

  const handleSendProtocol = () => {
    addTimelineEvent('Send Protocol', 'ACLS Protocol 2024 transmitted');
  };

  const handleMarkCritical = () => {
    addTimelineEvent('Mark Critical Event', 'Incident flagged for quality review');
  };

  const handleCaptureSnapshot = () => {
    addTimelineEvent('Capture Snapshot', 'Multimodal sensor snapshot archived');
  };

  if (!sessionActive) {
    return (
      <div className="bg-white rounded-lg shadow-lg p-6 border-2 border-gray-200">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-3">
            <div className="bg-gray-400 p-3 rounded-lg">
              <Video className="w-6 h-6 text-white" />
            </div>
            <div>
              <h2 className="text-xl font-bold text-gray-800">Collaboration Hub</h2>
              <p className="text-sm text-gray-500">Remote Expert Coordination</p>
            </div>
          </div>
        </div>
        <div className="py-12 text-center">
          <Video className="w-16 h-16 text-gray-300 mx-auto mb-4" />
          <p className="text-gray-500">No active collaboration session</p>
          <p className="text-sm text-gray-400 mt-2">Start a session to enable remote guidance</p>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-lg shadow-lg p-6 border-2 border-green-300">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center space-x-3">
          <div className="bg-green-500 p-3 rounded-lg animate-pulse">
            <Video className="w-6 h-6 text-white" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-gray-800">Collaboration Hub</h2>
            <p className="text-sm text-green-600 font-semibold">ACTIVE SESSION</p>
          </div>
        </div>
        <button
          onClick={onEnd}
          className="px-4 py-2 bg-red-500 text-white rounded-lg font-semibold hover:bg-red-600 transition-colors"
        >
          End Session
        </button>
      </div>

      <div className="aspect-video bg-gray-900 rounded-lg relative overflow-hidden mb-4">
        <div className="absolute inset-0 flex items-center justify-center">
          <Video className="w-16 h-16 text-gray-600 opacity-30" />
        </div>
        <div className="absolute top-4 left-4 bg-red-600 px-3 py-1 rounded-full flex items-center space-x-1">
          <div className="w-2 h-2 bg-white rounded-full animate-pulse"></div>
          <span className="text-white text-xs font-bold">LIVE</span>
        </div>
        <div className="absolute bottom-4 right-4 w-24 h-18 bg-gray-800 rounded-lg border-2 border-white overflow-hidden flex items-center justify-center">
          <Users className="w-6 h-6 text-gray-500" />
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4 mb-4">
        <div className="bg-blue-50 rounded-lg p-3 border border-blue-200">
          <p className="text-xs text-blue-600 mb-1">Expert</p>
          <p className="text-sm font-bold text-blue-900">{remoteClinician}</p>
        </div>
        <div className="bg-purple-50 rounded-lg p-3 border border-purple-200">
          <p className="text-xs text-purple-600 mb-1">Session Duration</p>
          <p className="text-sm font-bold text-purple-900">3 minutes</p>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-2 mb-4">
        <button
          onClick={handleEscalate}
          className="flex items-center justify-center space-x-2 px-3 py-2 bg-orange-100 text-orange-700 rounded-lg font-semibold hover:bg-orange-200 transition-colors text-sm"
        >
          <AlertTriangle className="w-4 h-4" />
          <span>Escalate</span>
        </button>
        <button
          onClick={handleSendProtocol}
          className="flex items-center justify-center space-x-2 px-3 py-2 bg-blue-100 text-blue-700 rounded-lg font-semibold hover:bg-blue-200 transition-colors text-sm"
        >
          <Send className="w-4 h-4" />
          <span>Send Protocol</span>
        </button>
        <button
          onClick={handleMarkCritical}
          className="flex items-center justify-center space-x-2 px-3 py-2 bg-red-100 text-red-700 rounded-lg font-semibold hover:bg-red-200 transition-colors text-sm"
        >
          <AlertTriangle className="w-4 h-4" />
          <span>Mark Critical</span>
        </button>
        <button
          onClick={handleCaptureSnapshot}
          className="flex items-center justify-center space-x-2 px-3 py-2 bg-green-100 text-green-700 rounded-lg font-semibold hover:bg-green-200 transition-colors text-sm"
        >
          <Camera className="w-4 h-4" />
          <span>Capture</span>
        </button>
      </div>

      <div className="border-t pt-4">
        <h3 className="text-sm font-bold text-gray-800 mb-3 flex items-center space-x-2">
          <Clock className="w-4 h-4 text-blue-600" />
          <span>Collaboration Timeline</span>
        </h3>
        <div className="space-y-2 max-h-40 overflow-y-auto">
          {timeline.map((event) => (
            <div
              key={event.id}
              className="flex items-start space-x-3 p-2 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors"
            >
              <CheckCircle className="w-4 h-4 text-green-500 mt-1 flex-shrink-0" />
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between">
                  <p className="font-semibold text-gray-800 text-sm">{event.action}</p>
                  <span className="text-xs text-gray-500 font-mono">{event.timestamp}</span>
                </div>
                <p className="text-xs text-gray-600 mt-1">{event.details}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
