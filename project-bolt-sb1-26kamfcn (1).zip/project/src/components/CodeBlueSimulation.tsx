import { AlertCircle, CheckCircle2, Clock, Play, RotateCcw } from 'lucide-react';
import { useState, useEffect } from 'react';

interface ChecklistItem {
  id: string;
  label: string;
  completed: boolean;
  timestamp?: string;
  duration?: number;
}

interface CodeBlueSimulationProps {
  isActive: boolean;
  onStart: () => void;
  onEnd: () => void;
  onGenerateSummary: () => void;
}

export default function CodeBlueSimulation({
  isActive,
  onStart,
  onEnd,
  onGenerateSummary,
}: CodeBlueSimulationProps) {
  const [elapsedSeconds, setElapsedSeconds] = useState(0);
  const [checklist, setChecklist] = useState<ChecklistItem[]>([
    { id: '1', label: 'Activate Code Blue Protocol', completed: false },
    { id: '2', label: 'Initiate CPR & Defibrillation', completed: false },
    { id: '3', label: 'Establish IV Access', completed: false },
    { id: '4', label: 'Administer Medications', completed: false },
    { id: '5', label: 'Confirm Rhythm Check', completed: false },
    { id: '6', label: 'Notify Intensive Care Unit', completed: false },
    { id: '7', label: 'Prepare Transport', completed: false },
  ]);

  useEffect(() => {
    if (!isActive) return;

    const interval = setInterval(() => {
      setElapsedSeconds((prev) => prev + 1);

      // Auto-complete checklist items based on time
      if (elapsedSeconds === 5 && !checklist[0].completed) {
        completeItem('1');
      }
      if (elapsedSeconds === 15 && !checklist[1].completed) {
        completeItem('2');
      }
      if (elapsedSeconds === 25 && !checklist[2].completed) {
        completeItem('3');
      }
      if (elapsedSeconds === 40 && !checklist[3].completed) {
        completeItem('4');
      }
      if (elapsedSeconds === 50 && !checklist[4].completed) {
        completeItem('5');
      }
    }, 1000);

    return () => clearInterval(interval);
  }, [isActive, elapsedSeconds, checklist]);

  const completeItem = (id: string) => {
    setChecklist((prev) =>
      prev.map((item) =>
        item.id === id && !item.completed
          ? {
              ...item,
              completed: true,
              timestamp: new Date().toLocaleTimeString(),
              duration: elapsedSeconds,
            }
          : item
      )
    );
  };

  const toggleItem = (id: string) => {
    setChecklist((prev) =>
      prev.map((item) =>
        item.id === id
          ? {
              ...item,
              completed: !item.completed,
              timestamp: !item.completed ? new Date().toLocaleTimeString() : undefined,
              duration: !item.completed ? elapsedSeconds : undefined,
            }
          : item
      )
    );
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const completionPercent = Math.round(
    (checklist.filter((item) => item.completed).length / checklist.length) * 100
  );

  const handleEnd = () => {
    onEnd();
    setElapsedSeconds(0);
  };

  const handleReset = () => {
    setElapsedSeconds(0);
    setChecklist((prev) =>
      prev.map((item) => ({
        ...item,
        completed: false,
        timestamp: undefined,
        duration: undefined,
      }))
    );
  };

  return (
    <div className="bg-white rounded-lg shadow-lg p-6 border-2 border-gray-200">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center space-x-3">
          <div className={`${isActive ? 'bg-red-500' : 'bg-gray-400'} p-3 rounded-lg animate-pulse`}>
            <AlertCircle className="w-6 h-6 text-white" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-gray-800">Code Blue Simulation</h2>
            <p className="text-sm text-gray-500">Critical Event Response Workflow</p>
          </div>
        </div>

        <div className="flex items-center space-x-3">
          {!isActive ? (
            <button
              onClick={onStart}
              className="flex items-center space-x-2 px-4 py-2 bg-red-500 text-white rounded-lg font-semibold hover:bg-red-600 transition-colors"
            >
              <Play className="w-4 h-4" />
              <span>Start Simulation</span>
            </button>
          ) : (
            <>
              <button
                onClick={handleReset}
                className="flex items-center space-x-2 px-4 py-2 bg-gray-300 text-gray-700 rounded-lg font-semibold hover:bg-gray-400 transition-colors"
              >
                <RotateCcw className="w-4 h-4" />
                <span>Reset</span>
              </button>
              <button
                onClick={handleEnd}
                className="flex items-center space-x-2 px-4 py-2 bg-orange-500 text-white rounded-lg font-semibold hover:bg-orange-600 transition-colors"
              >
                <AlertCircle className="w-4 h-4" />
                <span>End Event</span>
              </button>
            </>
          )}
        </div>
      </div>

      {isActive && (
        <div className="mb-6 p-4 bg-red-50 rounded-lg border-2 border-red-200">
          <div className="grid grid-cols-3 gap-4">
            <div className="text-center">
              <div className="flex items-center justify-center space-x-2 mb-2">
                <Clock className="w-5 h-5 text-red-600" />
                <p className="text-sm font-semibold text-red-900">Elapsed Time</p>
              </div>
              <p className="text-3xl font-bold text-red-600 font-mono">
                {formatTime(elapsedSeconds)}
              </p>
            </div>

            <div className="text-center">
              <p className="text-sm font-semibold text-red-900 mb-2">Progress</p>
              <div className="w-full bg-red-200 rounded-full h-2 mb-2">
                <div
                  className="bg-red-600 h-2 rounded-full transition-all duration-300"
                  style={{ width: `${completionPercent}%` }}
                ></div>
              </div>
              <p className="text-2xl font-bold text-red-600">
                {checklist.filter((item) => item.completed).length}/{checklist.length}
              </p>
            </div>

            <div className="text-center">
              <p className="text-sm font-semibold text-red-900 mb-2">Status</p>
              <p className="text-2xl font-bold text-red-600">
                {completionPercent === 100 ? 'COMPLETE' : 'IN PROGRESS'}
              </p>
            </div>
          </div>
        </div>
      )}

      <div className="space-y-2 mb-6">
        <h3 className="text-sm font-semibold text-gray-700">Critical Action Checklist</h3>
        {checklist.map((item) => (
          <div
            key={item.id}
            onClick={() => isActive && toggleItem(item.id)}
            className={`flex items-center space-x-3 p-3 rounded-lg cursor-pointer transition-all ${
              item.completed
                ? 'bg-green-50 border-2 border-green-200'
                : 'bg-gray-50 border-2 border-gray-200 hover:border-gray-300'
            }`}
          >
            <div
              className={`w-6 h-6 rounded-full flex items-center justify-center flex-shrink-0 ${
                item.completed
                  ? 'bg-green-500'
                  : 'bg-gray-300'
              }`}
            >
              {item.completed && <CheckCircle2 className="w-4 h-4 text-white" />}
            </div>

            <div className="flex-1">
              <p className={`font-semibold ${item.completed ? 'text-green-800' : 'text-gray-800'}`}>
                {item.label}
              </p>
            </div>

            {item.timestamp && (
              <div className="text-right">
                <p className="text-xs text-green-600 font-mono">{item.timestamp}</p>
                <p className="text-xs text-green-500">+{item.duration}s</p>
              </div>
            )}
          </div>
        ))}
      </div>

      {isActive && completionPercent === 100 && (
        <button
          onClick={onGenerateSummary}
          className="w-full px-4 py-3 bg-blue-600 text-white rounded-lg font-bold hover:bg-blue-700 transition-colors"
        >
          Generate Incident Summary
        </button>
      )}
    </div>
  );
}
