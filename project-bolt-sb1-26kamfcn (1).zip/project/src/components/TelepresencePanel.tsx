import { Video, VideoOff, Wifi, WifiOff, Users, Clock } from 'lucide-react';
import { TelepresenceSession } from '../types';

interface TelepresencePanelProps {
  session: TelepresenceSession | null;
  onStartSession?: () => void;
  onEndSession?: () => void;
}

export default function TelepresencePanel({ session, onStartSession, onEndSession }: TelepresencePanelProps) {
  const isActive = session?.status === 'active';
  const metrics = session?.video_quality_metrics || {};

  const getQualityColor = (value: number | undefined, thresholds: [number, number]) => {
    if (!value) return 'text-gray-400';
    if (value >= thresholds[0]) return 'text-green-500';
    if (value >= thresholds[1]) return 'text-yellow-500';
    return 'text-red-500';
  };

  const getLatencyColor = (latency: number | undefined) => {
    if (!latency) return 'text-gray-400';
    if (latency <= 100) return 'text-green-500';
    if (latency <= 200) return 'text-yellow-500';
    return 'text-red-500';
  };

  return (
    <div className="bg-white rounded-lg shadow-lg p-6 border-2 border-gray-200">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center space-x-3">
          <div className={`${isActive ? 'bg-green-500' : 'bg-gray-400'} p-3 rounded-lg`}>
            {isActive ? <Video className="w-6 h-6 text-white" /> : <VideoOff className="w-6 h-6 text-white" />}
          </div>
          <div>
            <h2 className="text-xl font-bold text-gray-800">Telepresence</h2>
            <p className="text-sm text-gray-500">Bidirectional Video Consultation</p>
          </div>
        </div>
        {isActive ? (
          <button
            onClick={onEndSession}
            className="px-4 py-2 bg-red-500 text-white rounded-lg font-semibold hover:bg-red-600 transition-colors"
          >
            End Session
          </button>
        ) : (
          <button
            onClick={onStartSession}
            className="px-4 py-2 bg-green-500 text-white rounded-lg font-semibold hover:bg-green-600 transition-colors"
          >
            Start Session
          </button>
        )}
      </div>

      {isActive && session ? (
        <div className="space-y-4">
          <div className="aspect-video bg-gray-900 rounded-lg relative overflow-hidden">
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="text-center">
                <Video className="w-16 h-16 text-gray-600 mx-auto mb-2 animate-pulse" />
                <p className="text-gray-400 text-sm">Remote Clinician Feed</p>
              </div>
            </div>
            <div className="absolute top-4 left-4 bg-red-600 px-3 py-1 rounded-full flex items-center space-x-1">
              <div className="w-2 h-2 bg-white rounded-full animate-pulse"></div>
              <span className="text-white text-xs font-bold">LIVE</span>
            </div>
            <div className="absolute bottom-4 right-4 w-32 h-24 bg-gray-800 rounded-lg border-2 border-white overflow-hidden">
              <div className="w-full h-full flex items-center justify-center">
                <Users className="w-8 h-8 text-gray-500" />
              </div>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="bg-gray-50 rounded-lg p-4">
              <div className="flex items-center space-x-2 mb-2">
                <Users className="w-5 h-5 text-blue-500" />
                <span className="text-sm font-semibold text-gray-700">Remote Clinician</span>
              </div>
              <p className="text-lg font-bold text-gray-800">{session.remote_clinician_id}</p>
            </div>

            <div className="bg-gray-50 rounded-lg p-4">
              <div className="flex items-center space-x-2 mb-2">
                <Clock className="w-5 h-5 text-blue-500" />
                <span className="text-sm font-semibold text-gray-700">Session Duration</span>
              </div>
              <p className="text-lg font-bold text-gray-800">
                {Math.floor((Date.now() - new Date(session.session_start).getTime()) / 60000)} min
              </p>
            </div>
          </div>

          <div className="border-t pt-4">
            <h3 className="text-sm font-semibold text-gray-700 mb-3">Video Quality Metrics</h3>
            <div className="grid grid-cols-3 gap-3">
              <div className="flex items-center space-x-2">
                <Wifi className={`w-5 h-5 ${getQualityColor(metrics.bandwidth, [5000, 2000])}`} />
                <div>
                  <p className="text-xs text-gray-500">Bandwidth</p>
                  <p className={`text-sm font-semibold ${getQualityColor(metrics.bandwidth, [5000, 2000])}`}>
                    {metrics.bandwidth ? `${(metrics.bandwidth / 1000).toFixed(1)} Mbps` : 'N/A'}
                  </p>
                </div>
              </div>

              <div className="flex items-center space-x-2">
                <Clock className={`w-5 h-5 ${getLatencyColor(metrics.latency)}`} />
                <div>
                  <p className="text-xs text-gray-500">Latency</p>
                  <p className={`text-sm font-semibold ${getLatencyColor(metrics.latency)}`}>
                    {metrics.latency ? `${metrics.latency} ms` : 'N/A'}
                  </p>
                </div>
              </div>

              <div className="flex items-center space-x-2">
                {(metrics.packet_loss || 0) < 1 ? (
                  <Wifi className="w-5 h-5 text-green-500" />
                ) : (
                  <WifiOff className="w-5 h-5 text-red-500" />
                )}
                <div>
                  <p className="text-xs text-gray-500">Packet Loss</p>
                  <p className={`text-sm font-semibold ${(metrics.packet_loss || 0) < 1 ? 'text-green-500' : 'text-red-500'}`}>
                    {metrics.packet_loss?.toFixed(2) || '0.00'}%
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      ) : (
        <div className="py-12 text-center">
          <VideoOff className="w-16 h-16 text-gray-300 mx-auto mb-4" />
          <p className="text-gray-500">No active telepresence session</p>
          <p className="text-sm text-gray-400 mt-2">Start a session to connect with a remote clinician</p>
        </div>
      )}
    </div>
  );
}
