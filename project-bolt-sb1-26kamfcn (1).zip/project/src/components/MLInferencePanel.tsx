import { Brain, Cpu, Cloud, Zap, TrendingUp } from 'lucide-react';
import { MLInference } from '../types';

interface MLInferencePanelProps {
  inferences: MLInference[];
}

export default function MLInferencePanel({ inferences }: MLInferencePanelProps) {
  const recentInferences = inferences.slice(0, 5);

  const getInferenceIcon = (type: string) => {
    switch (type) {
      case 'triage':
        return TrendingUp;
      case 'anomaly':
        return Zap;
      case 'image_assessment':
        return Brain;
      case 'risk_score':
        return TrendingUp;
      default:
        return Brain;
    }
  };

  const getInferenceColor = (type: string) => {
    switch (type) {
      case 'triage':
        return 'bg-blue-500';
      case 'anomaly':
        return 'bg-red-500';
      case 'image_assessment':
        return 'bg-purple-500';
      case 'risk_score':
        return 'bg-orange-500';
      default:
        return 'bg-gray-500';
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-lg p-6 border-2 border-gray-200">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center space-x-3">
          <div className="bg-gradient-to-br from-purple-500 to-blue-600 p-3 rounded-lg">
            <Brain className="w-6 h-6 text-white" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-gray-800">Edge Intelligence</h2>
            <p className="text-sm text-gray-500">On-Device ML Inferences</p>
          </div>
        </div>
        <div className="flex items-center space-x-2 bg-green-50 px-3 py-1 rounded-full">
          <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
          <span className="text-xs text-green-700 font-medium">{inferences.length} ACTIVE</span>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4 mb-6">
        <div className="bg-gradient-to-br from-blue-50 to-blue-100 rounded-lg p-4">
          <div className="flex items-center space-x-2 mb-2">
            <Cpu className="w-5 h-5 text-blue-600" />
            <span className="text-sm font-semibold text-blue-900">Edge Execution</span>
          </div>
          <p className="text-2xl font-bold text-blue-900">
            {inferences.filter(i => i.execution_location === 'edge').length}
          </p>
          <p className="text-xs text-blue-700 mt-1">Low-latency local processing</p>
        </div>

        <div className="bg-gradient-to-br from-purple-50 to-purple-100 rounded-lg p-4">
          <div className="flex items-center space-x-2 mb-2">
            <Cloud className="w-5 h-5 text-purple-600" />
            <span className="text-sm font-semibold text-purple-900">Cloud Execution</span>
          </div>
          <p className="text-2xl font-bold text-purple-900">
            {inferences.filter(i => i.execution_location === 'cloud').length}
          </p>
          <p className="text-xs text-purple-700 mt-1">High-complexity models</p>
        </div>
      </div>

      <div className="space-y-3">
        <h3 className="text-sm font-semibold text-gray-700">Recent Inferences</h3>
        {recentInferences.length > 0 ? (
          recentInferences.map((inference) => {
            const Icon = getInferenceIcon(inference.inference_type);
            const colorClass = getInferenceColor(inference.inference_type);

            return (
              <div key={inference.id} className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow">
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-center space-x-3">
                    <div className={`${colorClass} p-2 rounded-lg`}>
                      <Icon className="w-4 h-4 text-white" />
                    </div>
                    <div>
                      <h4 className="font-semibold text-gray-800 text-sm">{inference.model_name}</h4>
                      <p className="text-xs text-gray-500">
                        {inference.inference_type.replace('_', ' ').toUpperCase()} • v{inference.model_version}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-2">
                    {inference.execution_location === 'edge' ? (
                      <div className="flex items-center space-x-1 bg-blue-50 px-2 py-1 rounded-full">
                        <Cpu className="w-3 h-3 text-blue-600" />
                        <span className="text-xs text-blue-600 font-medium">EDGE</span>
                      </div>
                    ) : (
                      <div className="flex items-center space-x-1 bg-purple-50 px-2 py-1 rounded-full">
                        <Cloud className="w-3 h-3 text-purple-600" />
                        <span className="text-xs text-purple-600 font-medium">CLOUD</span>
                      </div>
                    )}
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3 text-xs">
                  <div className="bg-gray-50 rounded p-2">
                    <span className="text-gray-500">Latency</span>
                    <p className="font-semibold text-gray-800 mt-1">
                      {inference.latency_ms}ms
                    </p>
                  </div>
                  <div className="bg-gray-50 rounded p-2">
                    <span className="text-gray-500">Timestamp</span>
                    <p className="font-semibold text-gray-800 mt-1">
                      {new Date(inference.timestamp).toLocaleTimeString()}
                    </p>
                  </div>
                </div>

                {inference.output_data && Object.keys(inference.output_data).length > 0 && (
                  <div className="mt-3 p-2 bg-gray-50 rounded">
                    <p className="text-xs text-gray-500 mb-1">Output</p>
                    <div className="font-mono text-xs text-gray-700">
                      {Object.entries(inference.output_data).slice(0, 2).map(([key, value]) => (
                        <div key={key}>
                          <span className="text-gray-500">{key}:</span>{' '}
                          <span className="font-semibold">{String(value)}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            );
          })
        ) : (
          <div className="py-8 text-center">
            <Brain className="w-12 h-12 text-gray-300 mx-auto mb-2" />
            <p className="text-gray-500 text-sm">No inferences available</p>
          </div>
        )}
      </div>
    </div>
  );
}
