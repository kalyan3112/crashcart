import { Network, TrendingUp, AlertCircle, CheckCircle, Activity } from 'lucide-react';
import { CrashCart, FleetAnalytics } from '../types';

interface FleetDashboardProps {
  carts: CrashCart[];
  analytics: FleetAnalytics[];
}

export default function FleetDashboard({ carts, analytics }: FleetDashboardProps) {
  const activeCarts = carts.filter(c => c.status === 'active').length;
  const maintenanceCarts = carts.filter(c => c.status === 'maintenance').length;
  const offlineCarts = carts.filter(c => c.status === 'offline').length;
  const recentAnalytics = analytics.slice(0, 3);

  return (
    <div className="bg-white rounded-lg shadow-lg p-6 border-2 border-gray-200">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center space-x-3">
          <div className="bg-gradient-to-br from-blue-500 to-cyan-600 p-3 rounded-lg">
            <Network className="w-6 h-6 text-white" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-gray-800">Fleet Intelligence</h2>
            <p className="text-sm text-gray-500">Swarm-Level Analytics & Coordination</p>
          </div>
        </div>
        <div className="text-right">
          <p className="text-3xl font-bold text-gray-800">{carts.length}</p>
          <p className="text-sm text-gray-500">Total Carts</p>
        </div>
      </div>

      <div className="grid grid-cols-3 gap-4 mb-6">
        <div className="bg-gradient-to-br from-green-50 to-green-100 rounded-lg p-4 border border-green-200">
          <div className="flex items-center justify-between mb-2">
            <CheckCircle className="w-5 h-5 text-green-600" />
            <span className="text-2xl font-bold text-green-900">{activeCarts}</span>
          </div>
          <p className="text-sm text-green-800 font-medium">Active</p>
          <p className="text-xs text-green-600 mt-1">Operational units</p>
        </div>

        <div className="bg-gradient-to-br from-yellow-50 to-yellow-100 rounded-lg p-4 border border-yellow-200">
          <div className="flex items-center justify-between mb-2">
            <Activity className="w-5 h-5 text-yellow-600" />
            <span className="text-2xl font-bold text-yellow-900">{maintenanceCarts}</span>
          </div>
          <p className="text-sm text-yellow-800 font-medium">Maintenance</p>
          <p className="text-xs text-yellow-600 mt-1">Scheduled service</p>
        </div>

        <div className="bg-gradient-to-br from-red-50 to-red-100 rounded-lg p-4 border border-red-200">
          <div className="flex items-center justify-between mb-2">
            <AlertCircle className="w-5 h-5 text-red-600" />
            <span className="text-2xl font-bold text-red-900">{offlineCarts}</span>
          </div>
          <p className="text-sm text-red-800 font-medium">Offline</p>
          <p className="text-xs text-red-600 mt-1">Connection lost</p>
        </div>
      </div>

      <div className="mb-6">
        <h3 className="text-sm font-semibold text-gray-700 mb-3">Active Carts</h3>
        <div className="space-y-2 max-h-48 overflow-y-auto">
          {carts.slice(0, 5).map((cart) => (
            <div key={cart.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
              <div className="flex items-center space-x-3">
                <div className={`w-3 h-3 rounded-full ${
                  cart.status === 'active' ? 'bg-green-500' :
                  cart.status === 'maintenance' ? 'bg-yellow-500' :
                  'bg-red-500'
                }`}></div>
                <div>
                  <p className="font-semibold text-gray-800 text-sm">{cart.serial_number}</p>
                  <p className="text-xs text-gray-500">{cart.location}</p>
                </div>
              </div>
              <div className="text-right">
                <p className="text-xs text-gray-500">
                  {new Date(cart.last_heartbeat).toLocaleTimeString()}
                </p>
                <p className="text-xs text-gray-400">v{cart.firmware_version}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="border-t pt-6">
        <h3 className="text-sm font-semibold text-gray-700 mb-3">Fleet Analytics Insights</h3>
        {recentAnalytics.length > 0 ? (
          <div className="space-y-3">
            {recentAnalytics.map((analytics) => (
              <div key={analytics.id} className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow">
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-center space-x-3">
                    <div className="bg-blue-100 p-2 rounded-lg">
                      <TrendingUp className="w-4 h-4 text-blue-600" />
                    </div>
                    <div>
                      <h4 className="font-semibold text-gray-800 text-sm">
                        {analytics.analysis_type.replace('_', ' ').toUpperCase()}
                      </h4>
                      <p className="text-xs text-gray-500">
                        {analytics.cart_ids.length} carts analyzed
                      </p>
                    </div>
                  </div>
                  <div className="bg-green-50 px-2 py-1 rounded-full">
                    <span className="text-xs text-green-700 font-medium">
                      {Math.round(analytics.confidence_score * 100)}% confidence
                    </span>
                  </div>
                </div>

                {analytics.recommendations && analytics.recommendations.length > 0 && (
                  <div className="bg-blue-50 rounded p-3">
                    <p className="text-xs text-blue-900 font-medium mb-2">Recommendations:</p>
                    <ul className="space-y-1">
                      {analytics.recommendations.slice(0, 2).map((rec, idx) => (
                        <li key={idx} className="text-xs text-blue-800 flex items-start">
                          <span className="mr-2">•</span>
                          <span>{JSON.stringify(rec)}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}

                <p className="text-xs text-gray-400 mt-2">
                  {new Date(analytics.analysis_timestamp).toLocaleString()}
                </p>
              </div>
            ))}
          </div>
        ) : (
          <div className="py-8 text-center">
            <Network className="w-12 h-12 text-gray-300 mx-auto mb-2" />
            <p className="text-gray-500 text-sm">No fleet analytics available</p>
            <p className="text-xs text-gray-400 mt-1">Analytics will appear as patterns are discovered</p>
          </div>
        )}
      </div>

      <div className="border-t pt-4 mt-4">
        <div className="grid grid-cols-3 gap-3 text-xs">
          <div className="bg-gray-50 rounded-lg p-3">
            <p className="text-gray-500 mb-1">Shared Learning</p>
            <p className="font-semibold text-gray-800">Cross-cart model updates</p>
          </div>
          <div className="bg-gray-50 rounded-lg p-3">
            <p className="text-gray-500 mb-1">Pattern Discovery</p>
            <p className="font-semibold text-gray-800">Population-level insights</p>
          </div>
          <div className="bg-gray-50 rounded-lg p-3">
            <p className="text-gray-500 mb-1">Optimization</p>
            <p className="font-semibold text-gray-800">Operational efficiency</p>
          </div>
        </div>
      </div>
    </div>
  );
}
