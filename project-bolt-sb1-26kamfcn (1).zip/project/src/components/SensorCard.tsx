import { Activity, Zap, Radio } from 'lucide-react';
import { SensorData } from '../types';

interface SensorCardProps {
  sensor: SensorData;
  isActive?: boolean;
}

export default function SensorCard({ sensor, isActive = true }: SensorCardProps) {
  const sensorConfig = {
    ultrasound: { label: 'Portable Ultrasound', color: 'bg-blue-500', icon: Radio },
    xray: { label: 'Portable X-Ray', color: 'bg-purple-500', icon: Zap },
    pulse_ox: { label: 'Pulse Oximetry', color: 'bg-red-500', icon: Activity },
    ecg: { label: 'ECG', color: 'bg-green-500', icon: Activity },
    bp: { label: 'Blood Pressure', color: 'bg-orange-500', icon: Activity },
    temp: { label: 'Temperature', color: 'bg-yellow-500', icon: Activity },
    resp: { label: 'Respiration', color: 'bg-cyan-500', icon: Activity },
    spo2: { label: 'SpO2', color: 'bg-pink-500', icon: Activity },
    etco2: { label: 'EtCO2', color: 'bg-indigo-500', icon: Activity },
    glucose: { label: 'Glucose', color: 'bg-teal-500', icon: Activity },
  };

  const config = sensorConfig[sensor.sensor_type];
  const Icon = config.icon;
  const qualityPercent = Math.round(sensor.quality_score * 100);

  return (
    <div className={`bg-white rounded-lg border-2 ${isActive ? 'border-green-400 shadow-lg' : 'border-gray-200'} p-4 transition-all duration-300`}>
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center space-x-2">
          <div className={`${config.color} p-2 rounded-lg`}>
            <Icon className="w-5 h-5 text-white" />
          </div>
          <div>
            <h3 className="font-semibold text-gray-800 text-sm">{config.label}</h3>
            <p className="text-xs text-gray-500">{new Date(sensor.timestamp).toLocaleTimeString()}</p>
          </div>
        </div>
        {isActive && (
          <div className="flex items-center space-x-1">
            <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
            <span className="text-xs text-green-600 font-medium">LIVE</span>
          </div>
        )}
      </div>

      <div className="space-y-2">
        <div className="flex justify-between items-center">
          <span className="text-xs text-gray-600">Signal Quality</span>
          <span className={`text-sm font-semibold ${qualityPercent >= 90 ? 'text-green-600' : qualityPercent >= 70 ? 'text-yellow-600' : 'text-red-600'}`}>
            {qualityPercent}%
          </span>
        </div>
        <div className="w-full bg-gray-200 rounded-full h-1.5">
          <div
            className={`h-1.5 rounded-full transition-all duration-300 ${qualityPercent >= 90 ? 'bg-green-500' : qualityPercent >= 70 ? 'bg-yellow-500' : 'bg-red-500'}`}
            style={{ width: `${qualityPercent}%` }}
          ></div>
        </div>

        <div className="mt-3 p-2 bg-gray-50 rounded text-xs font-mono text-gray-700">
          {Object.entries(sensor.reading_data).slice(0, 2).map(([key, value]) => (
            <div key={key} className="flex justify-between">
              <span className="text-gray-500">{key}:</span>
              <span className="font-semibold">{String(value)}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
