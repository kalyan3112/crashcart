import { Database, Users, Lock, X, CheckCircle, AlertCircle } from 'lucide-react';
import { useState } from 'react';

interface Integration {
  id: string;
  name: string;
  icon: React.ReactNode;
  status: 'connected' | 'disconnected' | 'error';
  description: string;
  config: Record<string, string>;
}

export default function IntegrationStrip() {
  const [integrations, setIntegrations] = useState<Integration[]>([
    {
      id: 'ehr',
      name: 'EHR System',
      icon: <Database className="w-5 h-5" />,
      status: 'connected',
      description: 'Electronic Health Records Integration',
      config: { endpoint: 'https://ehr.hospital.local/api', auth: 'OAuth2', sync: 'Real-time' },
    },
    {
      id: 'nursecall',
      name: 'Nurse Call',
      icon: <Users className="w-5 h-5" />,
      status: 'connected',
      description: 'Nursing Station Communication',
      config: { protocol: 'WebSocket', latency: '<100ms', coverage: '100%' },
    },
    {
      id: 'sso',
      name: 'SSO/LDAP',
      icon: <Lock className="w-5 h-5" />,
      status: 'disconnected',
      description: 'Single Sign-On & Directory',
      config: { provider: 'Microsoft AD', sync: 'Scheduled', lastSync: '2 hours ago' },
    },
  ]);

  const [selectedIntegration, setSelectedIntegration] = useState<string | null>(null);
  const [showAuditLog, setShowAuditLog] = useState(false);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'connected':
        return 'bg-green-100 border-green-300 text-green-800';
      case 'error':
        return 'bg-red-100 border-red-300 text-red-800';
      default:
        return 'bg-yellow-100 border-yellow-300 text-yellow-800';
    }
  };

  const getStatusIcon = (status: string) => {
    if (status === 'connected') return <CheckCircle className="w-4 h-4 text-green-600" />;
    if (status === 'error') return <AlertCircle className="w-4 h-4 text-red-600" />;
    return <AlertCircle className="w-4 h-4 text-yellow-600" />;
  };

  const currentIntegration = integrations.find((i) => i.id === selectedIntegration);

  return (
    <div className="bg-white rounded-lg shadow-lg p-6 border-2 border-gray-200">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="text-xl font-bold text-gray-800">System Integrations</h2>
          <p className="text-sm text-gray-500">Third-party system connectivity & configuration</p>
        </div>
        <button
          onClick={() => setShowAuditLog(true)}
          className="px-4 py-2 bg-blue-600 text-white rounded-lg font-semibold hover:bg-blue-700 transition-colors text-sm"
        >
          View Audit Log
        </button>
      </div>

      <div className="grid grid-cols-3 gap-4">
        {integrations.map((integration) => (
          <button
            key={integration.id}
            onClick={() => setSelectedIntegration(selectedIntegration === integration.id ? null : integration.id)}
            className={`p-4 rounded-lg border-2 transition-all text-left ${
              selectedIntegration === integration.id
                ? 'border-blue-500 bg-blue-50 shadow-lg'
                : 'border-gray-200 bg-white hover:border-gray-300'
            }`}
          >
            <div className="flex items-center space-x-3 mb-3">
              <div className="text-gray-700">{integration.icon}</div>
              <div className="flex-1">
                <h3 className="font-bold text-gray-800">{integration.name}</h3>
                <p className="text-xs text-gray-500">{integration.description}</p>
              </div>
            </div>

            <div className={`flex items-center space-x-2 px-2 py-1 rounded-full text-xs font-semibold w-fit ${getStatusColor(integration.status)}`}>
              {getStatusIcon(integration.status)}
              <span>{integration.status.charAt(0).toUpperCase() + integration.status.slice(1)}</span>
            </div>
          </button>
        ))}
      </div>

      {selectedIntegration && currentIntegration && (
        <div className="mt-6 p-4 bg-blue-50 rounded-lg border-2 border-blue-200">
          <div className="flex items-start justify-between mb-3">
            <div>
              <h3 className="font-bold text-gray-800 text-lg">{currentIntegration.name}</h3>
              <p className="text-sm text-gray-600">{currentIntegration.description}</p>
            </div>
            <button
              onClick={() => setSelectedIntegration(null)}
              className="text-gray-400 hover:text-gray-600"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <div className="grid grid-cols-2 gap-4 mb-4">
            {Object.entries(currentIntegration.config).map(([key, value]) => (
              <div key={key} className="bg-white rounded-lg p-3 border border-gray-200">
                <p className="text-xs text-gray-600 mb-1 font-semibold">{key.toUpperCase()}</p>
                <p className="text-sm font-mono text-gray-800">{value}</p>
              </div>
            ))}
          </div>

          <div className="flex items-center space-x-3">
            <button
              className={`flex-1 px-4 py-2 rounded-lg font-semibold transition-colors ${
                currentIntegration.status === 'connected'
                  ? 'bg-orange-500 text-white hover:bg-orange-600'
                  : 'bg-green-500 text-white hover:bg-green-600'
              }`}
            >
              {currentIntegration.status === 'connected' ? 'Disconnect' : 'Connect'}
            </button>
            <button className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg font-semibold hover:bg-blue-700 transition-colors">
              Configure
            </button>
            <button className="flex-1 px-4 py-2 bg-gray-200 text-gray-800 rounded-lg font-semibold hover:bg-gray-300 transition-colors">
              Test Connection
            </button>
          </div>
        </div>
      )}

      {showAuditLog && (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-lg shadow-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <div className="sticky top-0 bg-gradient-to-r from-blue-500 to-blue-600 p-6 flex items-center justify-between">
              <h2 className="text-2xl font-bold text-white">Integration Audit Log</h2>
              <button
                onClick={() => setShowAuditLog(false)}
                className="bg-white bg-opacity-20 hover:bg-opacity-30 text-white p-2 rounded-lg transition-colors"
              >
                <X className="w-6 h-6" />
              </button>
            </div>

            <div className="p-6 space-y-3">
              {[
                {
                  timestamp: new Date(Date.now() - 3600000).toLocaleString(),
                  action: 'Configuration Updated',
                  system: 'EHR System',
                  user: 'admin@hospital.local',
                  details: 'API endpoint changed',
                  status: 'success',
                },
                {
                  timestamp: new Date(Date.now() - 7200000).toLocaleString(),
                  action: 'Connection Test',
                  system: 'Nurse Call',
                  user: 'system@hospital.local',
                  details: 'Health check passed',
                  status: 'success',
                },
                {
                  timestamp: new Date(Date.now() - 10800000).toLocaleString(),
                  action: 'Authentication Failed',
                  system: 'SSO/LDAP',
                  user: 'dr.smith@hospital.local',
                  details: 'Invalid credentials',
                  status: 'error',
                },
                {
                  timestamp: new Date(Date.now() - 86400000).toLocaleString(),
                  action: 'Integration Enabled',
                  system: 'EHR System',
                  user: 'admin@hospital.local',
                  details: 'Initial setup complete',
                  status: 'success',
                },
              ].map((log, idx) => (
                <div key={idx} className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow">
                  <div className="flex items-start justify-between mb-2">
                    <div>
                      <h4 className="font-bold text-gray-800">{log.action}</h4>
                      <p className="text-sm text-gray-600">{log.system}</p>
                    </div>
                    <div
                      className={`px-3 py-1 rounded-full text-xs font-semibold ${
                        log.status === 'success'
                          ? 'bg-green-100 text-green-800'
                          : 'bg-red-100 text-red-800'
                      }`}
                    >
                      {log.status.charAt(0).toUpperCase() + log.status.slice(1)}
                    </div>
                  </div>

                  <div className="grid grid-cols-3 gap-3 text-xs mt-3 pt-3 border-t">
                    <div>
                      <p className="text-gray-500 font-semibold">Timestamp</p>
                      <p className="text-gray-800 font-mono">{log.timestamp}</p>
                    </div>
                    <div>
                      <p className="text-gray-500 font-semibold">User</p>
                      <p className="text-gray-800 font-mono">{log.user}</p>
                    </div>
                    <div>
                      <p className="text-gray-500 font-semibold">Details</p>
                      <p className="text-gray-800">{log.details}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <div className="border-t p-6 bg-gray-50">
              <button
                onClick={() => setShowAuditLog(false)}
                className="w-full px-4 py-2 bg-blue-600 text-white rounded-lg font-semibold hover:bg-blue-700 transition-colors"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
