/*
  # Next-Generation Crash Cart System Infrastructure

  ## Overview
  This migration establishes the complete data architecture for a fleet of IoT-enabled 
  medical crash carts with integrated sensors, edge ML capabilities, and telepresence.

  ## New Tables

  ### 1. `crash_carts`
  Central registry of all deployed crash cart units
  - `id` (uuid, primary key) - Unique cart identifier
  - `serial_number` (text, unique) - Physical device serial number
  - `location` (text) - Current deployment location
  - `status` (text) - Operational status: active, maintenance, offline
  - `firmware_version` (text) - Current firmware version
  - `last_heartbeat` (timestamptz) - Last communication timestamp
  - `metadata` (jsonb) - Additional cart configuration and capabilities
  - `created_at` (timestamptz) - Cart registration date

  ### 2. `sensor_data`
  High-frequency sensor readings from all medical devices
  - `id` (uuid, primary key) - Unique reading identifier
  - `cart_id` (uuid, foreign key) - Associated cart
  - `sensor_type` (text) - Type: ultrasound, xray, pulse_ox, ecg, bp, temp, resp, spo2, etco2, glucose
  - `reading_data` (jsonb) - Sensor-specific structured data
  - `timestamp` (timestamptz) - Precise reading timestamp
  - `quality_score` (numeric) - Signal quality metric (0-1)
  - `synchronized_session_id` (uuid) - Groups synchronized multimodal readings

  ### 3. `ml_inferences`
  Edge and cloud ML model predictions and assessments
  - `id` (uuid, primary key) - Unique inference identifier
  - `cart_id` (uuid, foreign key) - Associated cart
  - `model_name` (text) - Model identifier
  - `model_version` (text) - Model version
  - `inference_type` (text) - Type: triage, anomaly, image_assessment, risk_score
  - `input_sensor_ids` (uuid[]) - Array of sensor reading IDs used as input
  - `output_data` (jsonb) - Model predictions and confidence scores
  - `execution_location` (text) - Where inference ran: edge, cloud
  - `latency_ms` (integer) - Inference execution time
  - `timestamp` (timestamptz) - Inference completion time

  ### 4. `telepresence_sessions`
  Bidirectional video consultation sessions
  - `id` (uuid, primary key) - Unique session identifier
  - `cart_id` (uuid, foreign key) - Associated cart
  - `remote_clinician_id` (text) - Remote expert identifier
  - `session_start` (timestamptz) - Session start time
  - `session_end` (timestamptz) - Session end time
  - `video_quality_metrics` (jsonb) - Bandwidth, latency, packet loss stats
  - `interventions_logged` (jsonb) - Clinical actions taken during session
  - `status` (text) - active, completed, interrupted

  ### 5. `operational_logs`
  System events, errors, and maintenance records
  - `id` (uuid, primary key) - Unique log identifier
  - `cart_id` (uuid, foreign key) - Associated cart
  - `log_level` (text) - Level: info, warning, error, critical
  - `event_type` (text) - Category of event
  - `message` (text) - Human-readable description
  - `metadata` (jsonb) - Additional structured context
  - `timestamp` (timestamptz) - Event occurrence time

  ### 6. `fleet_analytics`
  Aggregated insights across cart populations
  - `id` (uuid, primary key) - Unique analytics record
  - `analysis_timestamp` (timestamptz) - When analysis was performed
  - `cart_ids` (uuid[]) - Carts included in analysis
  - `analysis_type` (text) - Type: pattern_discovery, model_performance, operational_efficiency
  - `findings` (jsonb) - Structured analytical results
  - `recommendations` (jsonb) - System-generated improvement suggestions
  - `confidence_score` (numeric) - Confidence in findings (0-1)

  ## Security

  All tables have Row Level Security enabled with restrictive policies.
  Access is controlled through authenticated sessions only.

  ## Important Notes

  1. **Synchronized Acquisition**: The `synchronized_session_id` field enables 
     retrieval of time-aligned multimodal sensor data for comprehensive assessment.

  2. **Edge Intelligence**: The `execution_location` field tracks where ML inference
     occurred, supporting hybrid edge/cloud deployment strategies.

  3. **Fleet Coordination**: The `fleet_analytics` table enables swarm-level reasoning
     across multiple carts for pattern discovery and shared learning.

  4. **Telepresence Integration**: Session records link remote guidance with specific
     sensor data and ML inferences for complete clinical documentation.
*/

CREATE TABLE IF NOT EXISTS crash_carts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  serial_number text UNIQUE NOT NULL,
  location text NOT NULL DEFAULT '',
  status text NOT NULL DEFAULT 'active',
  firmware_version text NOT NULL DEFAULT '1.0.0',
  last_heartbeat timestamptz DEFAULT now(),
  metadata jsonb DEFAULT '{}'::jsonb,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE crash_carts ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated users can view all carts"
  ON crash_carts FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Authenticated users can insert carts"
  ON crash_carts FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Authenticated users can update carts"
  ON crash_carts FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE TABLE IF NOT EXISTS sensor_data (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  cart_id uuid REFERENCES crash_carts(id) ON DELETE CASCADE NOT NULL,
  sensor_type text NOT NULL,
  reading_data jsonb NOT NULL DEFAULT '{}'::jsonb,
  timestamp timestamptz DEFAULT now(),
  quality_score numeric DEFAULT 1.0,
  synchronized_session_id uuid,
  created_at timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_sensor_data_cart_id ON sensor_data(cart_id);
CREATE INDEX IF NOT EXISTS idx_sensor_data_timestamp ON sensor_data(timestamp DESC);
CREATE INDEX IF NOT EXISTS idx_sensor_data_session ON sensor_data(synchronized_session_id);

ALTER TABLE sensor_data ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated users can view all sensor data"
  ON sensor_data FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Authenticated users can insert sensor data"
  ON sensor_data FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE TABLE IF NOT EXISTS ml_inferences (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  cart_id uuid REFERENCES crash_carts(id) ON DELETE CASCADE NOT NULL,
  model_name text NOT NULL,
  model_version text NOT NULL DEFAULT '1.0',
  inference_type text NOT NULL,
  input_sensor_ids uuid[] DEFAULT ARRAY[]::uuid[],
  output_data jsonb NOT NULL DEFAULT '{}'::jsonb,
  execution_location text NOT NULL DEFAULT 'edge',
  latency_ms integer DEFAULT 0,
  timestamp timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_ml_inferences_cart_id ON ml_inferences(cart_id);
CREATE INDEX IF NOT EXISTS idx_ml_inferences_timestamp ON ml_inferences(timestamp DESC);

ALTER TABLE ml_inferences ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated users can view all ml inferences"
  ON ml_inferences FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Authenticated users can insert ml inferences"
  ON ml_inferences FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE TABLE IF NOT EXISTS telepresence_sessions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  cart_id uuid REFERENCES crash_carts(id) ON DELETE CASCADE NOT NULL,
  remote_clinician_id text NOT NULL,
  session_start timestamptz DEFAULT now(),
  session_end timestamptz,
  video_quality_metrics jsonb DEFAULT '{}'::jsonb,
  interventions_logged jsonb DEFAULT '[]'::jsonb,
  status text NOT NULL DEFAULT 'active'
);

CREATE INDEX IF NOT EXISTS idx_telepresence_cart_id ON telepresence_sessions(cart_id);
CREATE INDEX IF NOT EXISTS idx_telepresence_start ON telepresence_sessions(session_start DESC);

ALTER TABLE telepresence_sessions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated users can view all telepresence sessions"
  ON telepresence_sessions FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Authenticated users can insert telepresence sessions"
  ON telepresence_sessions FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Authenticated users can update telepresence sessions"
  ON telepresence_sessions FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE TABLE IF NOT EXISTS operational_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  cart_id uuid REFERENCES crash_carts(id) ON DELETE CASCADE NOT NULL,
  log_level text NOT NULL DEFAULT 'info',
  event_type text NOT NULL,
  message text NOT NULL,
  metadata jsonb DEFAULT '{}'::jsonb,
  timestamp timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_operational_logs_cart_id ON operational_logs(cart_id);
CREATE INDEX IF NOT EXISTS idx_operational_logs_timestamp ON operational_logs(timestamp DESC);
CREATE INDEX IF NOT EXISTS idx_operational_logs_level ON operational_logs(log_level);

ALTER TABLE operational_logs ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated users can view all operational logs"
  ON operational_logs FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Authenticated users can insert operational logs"
  ON operational_logs FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE TABLE IF NOT EXISTS fleet_analytics (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  analysis_timestamp timestamptz DEFAULT now(),
  cart_ids uuid[] DEFAULT ARRAY[]::uuid[],
  analysis_type text NOT NULL,
  findings jsonb NOT NULL DEFAULT '{}'::jsonb,
  recommendations jsonb DEFAULT '[]'::jsonb,
  confidence_score numeric DEFAULT 0.0
);

CREATE INDEX IF NOT EXISTS idx_fleet_analytics_timestamp ON fleet_analytics(analysis_timestamp DESC);

ALTER TABLE fleet_analytics ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated users can view all fleet analytics"
  ON fleet_analytics FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Authenticated users can insert fleet analytics"
  ON fleet_analytics FOR INSERT
  TO authenticated
  WITH CHECK (true);